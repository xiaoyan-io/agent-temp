/chat-support-agent/
├── README.md
├── SOUL.md
├── IDENTITY.md
├── POLICY.md
├── PROJECT_PROFILE.md
├── COMMANDS.md
├── FAQ_EXAMPLES.md
├── TEST_CASES.md
├── REPLY_TEMPLATES.md
├── ONBOARDING_GUIDE.md
└── HANDOFF_CHECKLIST.md